from tkinter import *
import math

# i forgot how to upload files to git hold on

# ball colors
BALL_COLORS = ['blue', 'red', 'green', 'orange', 'purple', 'black']

# default variables for selected colors
selected_color1 = BALL_COLORS[0]
selected_color2 = BALL_COLORS[1]

# Function to update color for ball 1
def set_color1(color):
    global selected_color1
    selected_color1 = color
    color_label1.config(text=f"Ball 1 Color: {color}")

# Function to update color for ball 2
def set_color2(color):
    global selected_color2
    selected_color2 = color
    color_label2.config(text=f"Ball 2 Color: {color}")

# angle validation (similar style to velocity validation)
def validate_angle(input_str):
    if not input_str.strip():
        return False, "Angle is empty"
    try:
        val = float(input_str)
        if not (0 <= val <= 360):
            return False, "Angle must be between 0 and 360 degrees"
        return True, val
    except ValueError:
        return False, "Angle is not a valid number"

# checks if input isn't a whitespace or invalid number
def validate_velocity(input_str):
    if not input_str.strip():
        return False, "Input is empty"
    try:
        val = float(input_str)
        if not (1 <= val <= 20):
            return False, "Input must be between 1 and 20"
        return True, val
    except ValueError:
        return False, "Input is not a valid number"

def get_velocities():
    v1 = v1_entry.get()
    v2 = v2_entry.get()
    a1 = angle1_entry.get()
    a2 = angle2_entry.get()

    valid1, result1 = validate_velocity(v1)
    valid2, result2 = validate_velocity(v2)
    valid_a1, angle1 = validate_angle(a1)
    valid_a2, angle2 = validate_angle(a2)

    if valid1 and valid2 and valid_a1 and valid_a2:
        error_label.config(text="")
        print(f"\nVelocities entered:\nVelocity 1: {result1} at {angle1}°\nVelocity 2: {result2} at {angle2}°")
        start_animation(result1, result2, angle1, angle2)
    else:
        error_msgs = []
        if not valid1:
            error_msgs.append(f"Ball 1 velocity error: {result1}")
        if not valid2:
            error_msgs.append(f"Ball 2 velocity error: {result2}")
        if not valid_a1:
            error_msgs.append(f"Ball 1 angle error: {angle1}")
        if not valid_a2:
            error_msgs.append(f"Ball 2 angle error: {angle2}")
        error_label.config(text="\n".join(error_msgs))

window = Tk()
window.title("Ball Collision")
window.geometry("1920x1080")

Label(window, text="Ball 1 Launch Angle (degrees):").pack()
angle1_entry = Entry(window, font=('Arial', 20))
angle1_entry.pack()

Label(window, text="Ball 2 Launch Angle (degrees):").pack()
angle2_entry = Entry(window, font=('Arial', 20))
angle2_entry.pack()

color_frame1 = Frame(window)
color_frame1.pack()
Label(color_frame1, text="Select Ball 1 Color:").pack()
color_label1 = Label(color_frame1, text=f"Ball 1 Color: {selected_color1}")
color_label1.pack()
for color in BALL_COLORS:
    btn = Button(color_frame1, bg=color, width=3, command=lambda c=color: set_color1(c))
    btn.pack(side='left', padx=2)

color_frame2 = Frame(window)
color_frame2.pack()
Label(color_frame2, text="Select Ball 2 Color:").pack()
color_label2 = Label(color_frame2, text=f"Ball 2 Color: {selected_color2}")
color_label2.pack()
for color in BALL_COLORS:
    btn = Button(color_frame2, bg=color, width=3, command=lambda c=color: set_color2(c))
    btn.pack(side='left', padx=2)

Label(window, text="Ball 1 Velocity:").pack()
v1_entry = Entry(window, font=('Arial', 20))
v1_entry.pack()

Label(window, text="Ball 2 Velocity:").pack()
v2_entry = Entry(window, font=('Arial', 20))
v2_entry.pack()

error_label = Label(window, text="", fg="red", font=('Arial', 10))
error_label.pack()

submit_button = Button(window, text="Submit", command=get_velocities)
submit_button.pack()

def clear_drawing():
    global ball1, ball2, dx1, dx2, dy1, dy2, animation_running
    animation_running = False
    dx1 = dx2 = dy1 = dy2 = 0
    if ball1:
        canvas.delete(ball1)
    if ball2:
        canvas.delete(ball2)

clear_button = Button(window, text="Clear Drawing", command=clear_drawing)
clear_button.pack()

canvas = Canvas(window, width=1280, height=600, bg='white')
canvas.pack()
canvas.create_line(100, 100, 100, 500, fill='black', width=10)
canvas.create_line(1180, 100, 1180, 500, fill='black', width=10)
canvas.create_line(100, 500, 1180, 500, fill='black', width=10)

ball1 = None
ball2 = None

# physics vars
ball_radius = 25  # approx from 50x50 oval
animation_running = True

# initialize
vx1 = vy1 = vx2 = vy2 = 0

def start_animation(v1, v2, a1, a2):
    global ball1, ball2, vx1, vy1, vx2, vy2, animation_running

    animation_running = True
    if ball1:
        canvas.delete(ball1)
    if ball2:
        canvas.delete(ball2)

    ball1 = canvas.create_oval(120, 250, 170, 300, fill=selected_color1)
    ball2 = canvas.create_oval(1130, 250, 1180, 300, fill=selected_color2)

    rad1 = math.radians(a1)
    rad2 = math.radians(a2)

    vx1 = v1 * math.cos(rad1)
    vy1 = -v1 * math.sin(rad1)
    vx2 = -v2 * math.cos(rad2)
    vy2 = -v2 * math.sin(rad2)

    animate()

def animate():
    global vx1, vy1, vx2, vy2

    if not animation_running:
        return

    canvas.move(ball1, vx1, vy1)
    canvas.move(ball2, vx2, vy2)

    pos1 = canvas.coords(ball1)
    pos2 = canvas.coords(ball2)

    # Gravity
    vy1 += 0.5 if pos1[3] < 500 or abs(vy1) > 0 else 0
    vy2 += 0.5 if pos2[3] < 500 or abs(vy2) > 0 else 0

    # Bounce from floor
    if pos1[3] >= 500:
        if abs(vy1) < 1:
            vy1 = 0
        else:
            vy1 = -abs(vy1) * 0.7

    if pos2[3] >= 500:
        if abs(vy2) < 1:
            vy2 = 0
        else:
            vy2 = -abs(vy2) * 0.7

    # Bounce from walls
    if pos1[0] <= 100 or pos1[2] >= 1180:
        vx1 *= -1
    if pos2[0] <= 100 or pos2[2] >= 1180:
        vx2 *= -1

    # Drag on floor
    if pos1[3] >= 500 and vy1 == 0:
        vx1 *= 0.9
        if abs(vx1) < 0.1:
            vx1 = 0
    if pos2[3] >= 500 and vy2 == 0:
        vx2 *= 0.9
        if abs(vx2) < 0.1:
            vx2 = 0

    # --- Tunneling fix ---
    if check_collision(pos1, pos2):
        resolve_collision()

    if any(abs(v) > 0.05 for v in [vx1, vy1, vx2, vy2]):
        window.after(20, animate)

def check_collision(pos1, pos2):
    x1, y1 = (pos1[0] + pos1[2]) / 2, (pos1[1] + pos1[3]) / 2
    x2, y2 = (pos2[0] + pos2[2]) / 2, (pos2[1] + pos2[3]) / 2
    dist = math.hypot(x2 - x1, y2 - y1)
    return dist <= 2 * ball_radius

# Improved bounce based on direction
def resolve_collision():
    global vx1, vy1, vx2, vy2
    vx1, vx2 = vx2, vx1
    vy1, vy2 = vy2, vy1

window.mainloop()
print("Program successfully ran!")
